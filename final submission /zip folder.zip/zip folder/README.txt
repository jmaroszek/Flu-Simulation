code.ipynb contains my analysis. PDF at the top level is my report.
